﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Services.DTO
{
    public class GroupDTO
    {
        public int Id { get; set; }
        public string GroupName { get; set; }=String.Empty;
        public int ParentId { get; set; }
        public bool IsChild { get; set; }
        public string ParentGroup { get; set; } = String.Empty;
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Store.Service.Store.Contract;
using Store.Services.DTO;

namespace Store.UI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SellController : ControllerBase
    {
        private readonly ISellService _sellService;

        public SellController(ISellService sellService)
        {
            _sellService = sellService;
        }
        [Route("GetSell")]
        [HttpGet]
        public ActionResult<List<SellDTO>> GetSell(int pagenumber, int pagelength)
        {
            return _sellService.GetSellPagination(pagenumber, pagelength);
        }
        [Route("GetOneSell")]
        [HttpGet]
        public SellDTO GetOneSell(int Id)
        {
            return _sellService.GetOneSell(Id);
        }
        [Route("AddSell")]
        [HttpPost]
        public async Task AddSell(SellDTO selldto)
        {
            await _sellService.AddSell(selldto);
        }
        [Route("EditSell")]
        [HttpPut]
        public async Task EditSell(SellDTO selldto)
        {
            await _sellService.EditSell(selldto);
        }
        [Route("DeleteSell")]
        [HttpDelete]
        public async Task DeleteSell(SellDTO selldto)
        {
            await _sellService.DeleteSell(selldto);
        }
    }
}

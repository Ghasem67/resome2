﻿using Store.Data.Contract.BaseContract;
using Store.Data.EntityRepository.BaseRepository;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.Contract.Store
{
    public interface IProductRepository: IRepository<Product>
    {
        List<Product> GetbyId(int Id, CancellationToken cancellationToken);
        List<Product> Get();
    }
}

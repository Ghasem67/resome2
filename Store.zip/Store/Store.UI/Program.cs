using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Store.Data.Contract.BaseContract;
using Store.Data.Contract.Store;
using Store.Data.Contract.User;
using Store.Data.Data;
using Store.Data.EntityRepository.BaseRepository;
using Store.Data.EntityRepository.Store;
using Store.Data.EntityRepository.User;
using Store.Service.Store.Contract;
using Store.Service.Store.Service;
using Store.Service.User.Contract;
using Store.Service.User.Service;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var Config = builder.Configuration.GetConnectionString("Coon");
builder.Services.AddDbContext<DataContext>(s=>s.UseSqlServer(Config));
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<ISellRepository, SellRepository>();
builder.Services.AddScoped<IShoppingBagRepository, ShoppingBagRepository>();
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<IGroupRepository, GroupRepository>();
//-------------------------service----------------------------
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<ISellService, SellService>();
builder.Services.AddScoped<IShoppingBagService, ShoppingBagService>();
builder.Services.AddScoped<IProductService, ProductService>();
builder.Services.AddScoped<IGroupService, GroupService>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

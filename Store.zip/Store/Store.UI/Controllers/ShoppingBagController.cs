﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Store.Service.Store.Contract;
using Store.Services.DTO;

namespace Store.UI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShoppingBagController : ControllerBase
    {
        private readonly IShoppingBagService _shoppingBagService;

        public ShoppingBagController(IShoppingBagService shoppingBagService)
        {
            _shoppingBagService = shoppingBagService;
        }
        [Route("GetShoppingbagPagination")]
        [HttpGet]
        public ActionResult<ShoppingBagDTO> GetShoppingbagPagination(int PageNumber, int PageLength)
        {
            var Shoppingbag = _shoppingBagService.GetShoppingBagPagination(PageNumber, PageLength);
            return Ok(Shoppingbag);
        }
        [Route("GetShoppingBagbyId")]
        [HttpGet]
        public ActionResult<ShoppingBagDTO> GetShoppingBagbyId(int Id)
        {
            return _shoppingBagService.GetOneShoppingBag(Id);
        }
        [Route("AddShoppingBag")]
        [HttpPost]
        public ActionResult AddShoppingBag(ShoppingBagDTO shoppingBagViewModel)
        {
            var result = _shoppingBagService.AddShoppingBag(shoppingBagViewModel);
            return Ok(result);
        }
    }
}

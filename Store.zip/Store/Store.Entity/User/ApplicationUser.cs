﻿
using Store.Entity.Base;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Entity.User
{
    public class ApplicationUser: BaseEntity<int>
    {
        public string Name { get; set; }=String.Empty;
        public string Family { get; set; } = String.Empty;
        public string UserName { get; set; } = String.Empty;
        public string Password { get; set; } = String.Empty;
        public string Email { get; set; } = String.Empty;
        public string PhoneNumber { get; set; } = String.Empty;
        public string NationalCode { get; set; } = String.Empty;
        public List<ShoppingBag> ShoppingBagList { get; set; }= new List<ShoppingBag>();
        public List<Sell> SellList { get; set; }=new List<Sell>();
    }
}

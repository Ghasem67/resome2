﻿using Store.Data.Contract.BaseContract;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.Contract.Store
{
    public interface ISellRepository : IRepository<Sell>
    {
        List<Sell> GetbyId(int Id, CancellationToken cancellationToken);
        List<Sell> Get();
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Entity.Configuration
{
    public class ShoopingBagConfiguration : IEntityTypeConfiguration<ShoppingBag>
    {
        public void Configure(EntityTypeBuilder<ShoppingBag> builder)
        {
            builder.HasOne(x => x.User).WithMany(x => x.ShoppingBagList).HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.NoAction);
            builder.HasOne(x => x.Sell).WithMany(x => x.ShoppingBagList).HasForeignKey(x => x.SellId).OnDelete(DeleteBehavior.Cascade);
            builder.HasOne(x => x.Product).WithMany(x => x.ShoppingBagList).HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Cascade);

        }
    }
}

﻿
using Store.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Entity.Store
{
    public class Product:BaseEntity<int>
    {

        public string ProductName { get; set; }=String.Empty;
        public long Cost { get; set; }
        public int Inventory { get; set; }
        public int GroupId { get; set; }
        public Group Group { get; set; }
        public List<ShoppingBag> ShoppingBagList { get; set; }

    }
}

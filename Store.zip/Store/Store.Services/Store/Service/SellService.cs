﻿using Store.Data.Contract.Store;
using Store.Entity.Store;
using Store.Service.Store.Contract;
using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.Store.Service
{
    public class SellService : ISellService
    {
        private readonly ISellRepository _sellRepository;

        public SellService(ISellRepository sellRepository)
        {
            _sellRepository = sellRepository;
        }

        public async Task AddSell(SellDTO sellDTO)
        {
            CancellationToken cancellationToken = new();
            Sell sell = new()
            {
                SellDate = DateTime.Now,
                UserId = sellDTO.UserId,
                FactoreNumber = sellDTO.FactoreNumber

            };
            await _sellRepository.AddAsync(sell, cancellationToken);
        }

        public SellDTO GetOneSell(int Id)
        {
            CancellationToken cancellationToken = new();
            return _sellRepository.GetbyId(Id, cancellationToken).Select(x => new SellDTO { SellDate = x.SellDate.ToString(), UserId = x.UserId, FactoreNumber = x.FactoreNumber,Id=x.Id,UserName=x.User.UserName }).First();
        }

        public List<SellDTO> GetSellPagination(int PageNumber, int PageLength)
        {
            var s = _sellRepository.Get().Skip(--PageNumber * PageLength).Take(PageLength).ToList();
            return s.Select(x => new SellDTO { UserId = x.UserId, FactoreNumber = x.FactoreNumber, SellDate = x.SellDate.ToString(), Id = x.Id, UserName = x.User.UserName }).ToList(); ;
        }


        public async Task DeleteSell(SellDTO sellDTO)
        {
            CancellationToken cancellationToken = new();
            Sell sell = _sellRepository.GetbyId(sellDTO.Id,cancellationToken).First();
            await _sellRepository.DeleteAsync(sell, cancellationToken);
        }

        public async Task EditSell(SellDTO sellDTO)
        {
            CancellationToken cancellationToken = new();
            Sell sell = new ()
            {
                FactoreNumber = sellDTO.FactoreNumber,
                Id = sellDTO.Id,
                SellDate= DateTime.Parse(sellDTO.SellDate),
                UserId =sellDTO.UserId,

            };
            await _sellRepository.EditAsync(sell, cancellationToken);
        }
    }
}

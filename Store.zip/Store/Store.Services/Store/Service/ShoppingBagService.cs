﻿using Store.Data.Contract.Store;
using Store.Entity.Store;
using Store.Service.Store.Contract;
using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.Store.Service
{
    public class ShoppingBagService : IShoppingBagService
    {
        private readonly IShoppingBagRepository _shoppingBagRepository;

        public ShoppingBagService(IShoppingBagRepository shoppingBagRepository)
        {
            _shoppingBagRepository = shoppingBagRepository;
        }
        public  async Task AddShoppingBag(ShoppingBagDTO shoppingBagDTO)
        {
            ShoppingBag shoppingBag = new ()
            {
                Cost = shoppingBagDTO.Cost,
                Number = shoppingBagDTO.Number,
                ProductId = shoppingBagDTO.ProductId,
                UserId = shoppingBagDTO.UserId,
            };
            CancellationToken cancellationToken = new ();
           await _shoppingBagRepository.AddAsync(shoppingBag, cancellationToken);
        }
        public async Task EditShoppingBag(ShoppingBagDTO shoppingBagDTO)
        {  CancellationToken cancellationToken = new();
            var shoppingBag = _shoppingBagRepository.GetbyId(shoppingBagDTO.Id,cancellationToken).First();
            shoppingBag.Cost = shoppingBagDTO.Cost;
            shoppingBag.Number=shoppingBagDTO.Number;
            await _shoppingBagRepository.EditAsync(shoppingBag, cancellationToken);
        }

        public ShoppingBagDTO GetOneShoppingBag(int Id)
        {
            CancellationToken cancellationToken = new ();
         return   _shoppingBagRepository.GetbyId(Id, cancellationToken).Select(x=>new ShoppingBagDTO 
         { Id=x.Id,
             Cost=x.Cost,
             Number=x.Number,
             ProductId=x.ProductId,
             SellId=x.SellId
             ,UserId=x.UserId}).First();
        }

        public  List<ShoppingBagDTO> GetShoppingBagPagination(int PageNumber, int PageLength)
        {
           return _shoppingBagRepository.Get().Skip(--PageNumber* PageLength).Take(PageLength).Select(x => new ShoppingBagDTO {Id=x.Id,Cost=x.Cost,Number=x.Number,ProductId=x.ProductId,SellId=x.SellId,UserId=x.UserId }).ToList();
        }

        public async Task DeleteShoppingBag(ShoppingBagDTO shoppingBagDTO)
        {
            CancellationToken cancellationToken=new ();
            var shoppingbag = _shoppingBagRepository.GetbyId(shoppingBagDTO.Id, cancellationToken).First();
            await _shoppingBagRepository.DeleteAsync(shoppingbag, cancellationToken);
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Store.Data.Contract.Store;
using Store.Data.Data;
using Store.Data.EntityRepository.BaseRepository;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.EntityRepository.Store
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public ProductRepository(DataContext dataContext ) : base(dataContext)
        {
        }

        public List< Product> GetbyId(int Id, CancellationToken cancellationToken)
        {
            return dataContext.Products.Where(x => x.Id.Equals(Id)).ToList();
        }

        public List<Product> Get()
        {
            return _entities.ToList();
        }

    }
}

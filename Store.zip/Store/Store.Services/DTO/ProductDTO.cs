﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Services.DTO
{
    public class ProductDTO
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public long Cost { get; set; }
        public int Inventory { get; set; }
        public int GroupId { get; set; }
        public string GroupName { get; set; }
    }
}

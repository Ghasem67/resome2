﻿using Microsoft.EntityFrameworkCore;
using Store.Data.Contract.Store;
using Store.Data.Data;
using Store.Data.EntityRepository.BaseRepository;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.EntityRepository.Store
{
    public class GroupRepository : Repository<Group>, IGroupRepository
    {
        public  GroupRepository(DataContext dataContext ) : base(dataContext)
        {
        }
        public List<Group> GetbyId(int Id, CancellationToken cancellationToken)
        {
            return _entities.Include(x=>x.ProductList).Where(x => x.Id == Id).ToList();
        }
      

        List<Group> IGroupRepository.Get()
        {
            return _entities.ToList();
        }
    }
}

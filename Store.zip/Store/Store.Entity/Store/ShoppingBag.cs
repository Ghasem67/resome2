﻿
using Store.Entity.Base;
using Store.Entity.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Entity.Store
{
    public class ShoppingBag : BaseEntity<int>
    {
     
        public int Cost { get; set; }
        public int Number { get; set; }
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public int SellId { get; set; }
        public ApplicationUser User { get; set; }=new ApplicationUser();
        public Sell Sell { get; set; }=new Sell();
        public Product Product { get; set; } = new Product();


    }
}

﻿using Microsoft.EntityFrameworkCore;
using Store.Entity.Configuration;
using Store.Entity.Store;
using Store.Entity.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(SellConfiguration).Assembly);
        }
        public DbSet<ApplicationUser> Users { get; set; }
        public DbSet<Sell>   Sells { get; set; }
        public DbSet<ShoppingBag> ShoppingBags { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Group> Groups { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Services.DTO
{
    public class ShoppingBagDTO
    {
        public int Id { get; set; }
        public int Cost { get; set; }
        public int Number { get; set; }
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public int SellId { get; set; }
        public string UserName { get; set; }
        //public Sell Sell { get; set; }
        public string ProductName { get; set; }
    }
}

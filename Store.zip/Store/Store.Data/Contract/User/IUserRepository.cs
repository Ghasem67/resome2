﻿using Store.Data.Contract.BaseContract;
using Store.Entity.User;

namespace Store.Data.Contract.User
{
    public interface IUserRepository :IRepository<ApplicationUser>
    {
        List<ApplicationUser> GetUserbyId(int UserId);
        List<ApplicationUser> Get();
    }
}
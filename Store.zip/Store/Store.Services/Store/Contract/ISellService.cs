﻿using Store.Data.Contract.Store;

using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.Store.Contract
{
    public interface ISellService
    {
        Task AddSell(SellDTO sellViewModel);
        Task EditSell(SellDTO sellViewModel);
        
        Task DeleteSell(SellDTO sellViewModel);
        List<SellDTO> GetSellPagination(int PageNumber, int PageLength);
        SellDTO GetOneSell(int Id);


            
    }
}

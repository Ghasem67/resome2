﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Services.DTO
{
    public class SellDTO
    {
        public int Id { get; set; }
        public string SellDate { get; set; }
        public int FactoreNumber { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
    }
}

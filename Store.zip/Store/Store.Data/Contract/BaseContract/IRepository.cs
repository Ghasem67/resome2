﻿using Microsoft.EntityFrameworkCore;
using Store.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.Contract.BaseContract
{
    public interface IRepository<TEntity> where TEntity : class, IEntity
    {


        Task AddAsync(TEntity entity, CancellationToken cancellationToken);
        Task EditAsync(TEntity entity, CancellationToken cancellationToken);
        Task DeleteAsync(TEntity entity, CancellationToken cancellationToken);
      


    }
}

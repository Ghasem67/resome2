﻿using Store.Data.Contract.Store;
using Store.Entity.Store;
using Store.Service.Store.Contract;
using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.Store.Service
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
        public async Task AddProduct(ProductDTO productDTO)
        {
            CancellationToken cancellationToken = new ();
            Product product=new ()
            {
                Cost= productDTO.Cost,
                GroupId= productDTO.GroupId,
                Inventory=productDTO.Inventory,
                ProductName=productDTO.ProductName
            };
           await _productRepository.AddAsync(product, cancellationToken);
        }
        public async Task EditProduct(ProductDTO productDTO )
        {
            CancellationToken cancellationToken = new ();
            var product= _productRepository.GetbyId(productDTO.Id, cancellationToken).First();
           await _productRepository.EditAsync(product, cancellationToken);
        }

        public ProductDTO GetOneProduct(int Id)
        {
            CancellationToken cancellationToken=new ();
          return  _productRepository.GetbyId(Id, cancellationToken).Select(x =>new ProductDTO{GroupId=x.GroupId,Cost=x.Cost,Inventory=x.Inventory,Id=x.Id,ProductName=x.ProductName } ).First();
        }

        public List<ProductDTO> GetProductPagination(int PageNumber, int PageLength)
        {
           return _productRepository.Get().Skip(--PageNumber* PageLength).Take(PageLength).Select(x => new ProductDTO { GroupId = x.GroupId, Cost = x.Cost, Inventory = x.Inventory, Id = x.Id, ProductName = x.ProductName }).ToList();
        }

        public async Task DeleteProduct(ProductDTO productDTO)
        {
           CancellationToken cancellationToken=new ();
           var Product= _productRepository.GetbyId(productDTO.Id, cancellationToken).First();
           await _productRepository.DeleteAsync(Product, cancellationToken);
        }

       
    }
}

﻿using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.User.Contract
{
    public interface IUserService
    {
        Task AddUser(UserDTO userViewModel);
        Task EditUser(UserDTO userViewModel);

        Task DeleteUser(UserDTO userViewModel);
        List<UserDTO> GetUserPagination(int PageNumber, int PageLength);
        UserDTO GetOneUser(int Id);
    }
}

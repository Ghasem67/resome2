﻿using Store.Data.Contract.Store;
using Store.Entity.Store;
using Store.Service.Store.Contract;
using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.Store.Service
{
    public class GroupService : IGroupService
    {
        private readonly IGroupRepository _groupRepository;

        public GroupService(IGroupRepository groupRepository)
        {
            _groupRepository = groupRepository;
        }
        public async Task AddGroup(GroupDTO groupViewModel)
        {
            CancellationToken cancellationToken = new ();
            Group group = new ()
            {
                GroupName = groupViewModel.GroupName,
                ParentId=(groupViewModel.ParentId==0?null:groupViewModel.ParentId),
            };
           await _groupRepository.AddAsync(group, cancellationToken);
        } 
        public async Task  EditGroup(GroupDTO groupViewModel)
        {CancellationToken cancellationToken=new ();
            Group group = _groupRepository.GetbyId(groupViewModel.Id,cancellationToken).First();
            group.GroupName = groupViewModel.GroupName;
           await _groupRepository.EditAsync(group,cancellationToken);
        }
        public List<GroupDTO> GetGroupPagination(int PageNumber, int PageLength)
        {
          return _groupRepository.Get().Skip(--PageNumber* PageLength).Select(groupViewModel => new GroupDTO
          {
               Id= groupViewModel.Id,
               GroupName= groupViewModel.GroupName,
               ParentId= (groupViewModel.ParentId.Equals(null)?0: groupViewModel.ParentId.Value)}).ToList();
        }
        public GroupDTO GetOneGroup(int Id)
        {
            CancellationToken cancellationToken = new ();
            return _groupRepository.GetbyId(Id, cancellationToken).Select(x => new GroupDTO { Id = x.Id, GroupName = x.GroupName, IsChild =(x.Child==null?false:true), ParentId = (x.ParentId != null ? x.ParentId.Value : 0),ParentGroup = (x.ParentId != null ? x.ParentGroup.ParentGroup.GroupName : String.Empty) }).First();
            



        }
        public async Task DeleteGroup(GroupDTO groupDTO)
        { 
            CancellationToken cancellationToken = new ();
            var group = _groupRepository.GetbyId(groupDTO.Id,cancellationToken).First();
            await _groupRepository.DeleteAsync(group, cancellationToken);
        }

     
    }
}

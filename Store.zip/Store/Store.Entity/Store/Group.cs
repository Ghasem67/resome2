﻿using Store.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Entity.Store
{
    public class Group : BaseEntity<int>
    {
     
        public string GroupName { get; set; }=String.Empty;
        public int? ParentId { get; set; }
        public Group ParentGroup { get; set; }
        public List<Group>? Child { get; set; }
        public List<Product>? ProductList { get; set; }



    }
}

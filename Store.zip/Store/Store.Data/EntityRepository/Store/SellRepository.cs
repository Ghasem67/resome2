﻿using Microsoft.EntityFrameworkCore;
using Store.Data.Contract.Store;
using Store.Data.Data;
using Store.Data.EntityRepository.BaseRepository;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.EntityRepository.Store
{
    public class SellRepository : Repository<Sell>, ISellRepository
    {
        public SellRepository(DataContext dataContext ) : base(dataContext)
        {
        }
        public  List<Sell> GetbyId(int Id, CancellationToken cancellationToken)
        {
            return dataContext.Set<Sell>().Where(x => x.Id == Id).ToList();
        }
        public List<Sell> Get()
        {
            return _entities.Include(x=>x.User).ToList();
        }
    }
}

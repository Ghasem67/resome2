﻿
using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.Store.Contract
{
    public interface IShoppingBagService
    {
        Task AddShoppingBag(ShoppingBagDTO shoppingBagDTO);

        Task DeleteShoppingBag(ShoppingBagDTO shoppingBagDTO);
        List<ShoppingBagDTO> GetShoppingBagPagination(int PageNumber, int PageLength);
        ShoppingBagDTO GetOneShoppingBag(int Id);
    }
}

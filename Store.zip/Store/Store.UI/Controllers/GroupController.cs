﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Store.Service.Store.Contract;
using Store.Services.DTO;

namespace Store.UI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupController : ControllerBase
    {
        private readonly IGroupService _groupService;

        public GroupController(IGroupService groupService)
        {
            _groupService = groupService;
        }

        [HttpGet]
        [Route("GetGroupList")]
        public ActionResult<List<GroupDTO>> GetGroupPagination(int pagenumber, int pagelength)
        {
            return _groupService.GetGroupPagination(pagenumber,  pagelength);

        }

        [HttpGet]
        [Route("GetOneGroup")]
        public ActionResult<GroupDTO> GetOneGroup(int id)
        {
            return _groupService.GetOneGroup(id);

        }

        [HttpPost]
        [Route("AddGroup")]
        public ActionResult AddGroup(GroupDTO groupDTO)
        {
           

            _groupService.AddGroup(groupDTO);
            return Ok();
        }

        [HttpPut]
        [Route("EditGroup")]
        public ActionResult EditGroup(GroupDTO groupDTO)
        {
           
         
            _groupService.EditGroup(groupDTO);
            return Ok();
        }

        [HttpDelete]
        [Route("DeleteGroup")]
        public ActionResult DeleteGroup(int id)
        {
            GroupDTO groupDTO = new()
            {
                Id = id
            };
            _groupService.DeleteGroup(groupDTO);
            return Ok();
        }
    }
}

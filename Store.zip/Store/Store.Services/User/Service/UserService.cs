﻿using Store.Data.Contract.User;
using Store.Entity.User;
using Store.Service.User.Contract;
using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.User.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }


        public async Task AddUser(UserDTO userViewModel)
        {
            CancellationToken cancellationToken = new ();
            ApplicationUser applicationUser = new ()
            {
                Email = userViewModel.Email,
                NationalCode = userViewModel.NationalCode,
                PhoneNumber = userViewModel.PhoneNumber,
                UserName = userViewModel.UserName,
                Family=userViewModel.Family,
                Name=userViewModel.Name,
                Password = userViewModel.Password

            };
            await _userRepository.AddAsync(applicationUser,cancellationToken);
        }
        public async Task EditUser(UserDTO userDTO)
        {
            CancellationToken cancellationToken = new ();
            var result = _userRepository.GetUserbyId(userDTO.Id).First();
            result.Name = userDTO.Name;
            result.Email = userDTO.Email;
            result.UserName = userDTO.UserName;
            result.Password = userDTO.Password;
            result.PhoneNumber = userDTO.PhoneNumber;
            result.Family = userDTO.Family;
            result.NationalCode = userDTO.NationalCode;
            await _userRepository.EditAsync(result, cancellationToken);
        }

        public UserDTO GetOneUser(int Id)
        {
            return _userRepository.GetUserbyId(Id).Select(x => new UserDTO { Email = x.Email, UserName = x.UserName, NationalCode = x.NationalCode, }).First();
        }

        public List<UserDTO> GetUserPagination(int PageNumber, int PageLength)
        {

            var UserList = _userRepository.Get().Skip((--PageNumber) * PageLength).Take(PageLength).Select(x => new UserDTO
            {
                Email = x.Email,
                Id = x.Id,
                NationalCode = x.NationalCode,
                Password = x.Password,
                PhoneNumber = x.PhoneNumber,
                UserName = x.UserName
            }).ToList();
            return UserList;

        }

        public async Task DeleteUser(UserDTO userViewModel)
        {
            CancellationToken cancellationToken = new ();
            var user = _userRepository.GetUserbyId(userViewModel.Id).First();
            await _userRepository.DeleteAsync(user, cancellationToken);
        }

       

       
    }
}

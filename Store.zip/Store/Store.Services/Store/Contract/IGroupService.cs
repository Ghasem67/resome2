﻿using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.Store.Contract
{
    public interface IGroupService
    {
        Task AddGroup(GroupDTO sellViewModel);
        Task EditGroup(GroupDTO sellViewModel);
        Task DeleteGroup(GroupDTO sellViewModel);
        List<GroupDTO> GetGroupPagination(int PageNumber, int PageLength);
        GroupDTO GetOneGroup(int Id);
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Store.Data.Contract.User;
using Store.Data.Data;
using Store.Data.EntityRepository.BaseRepository;
using Store.Entity.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.EntityRepository.User
{
    public class UserRepository : Repository<ApplicationUser>, IUserRepository
    {
        

      public UserRepository(DataContext dataContext) : base(dataContext)
        {

        }

        List<ApplicationUser> IUserRepository.GetUserbyId(int UserId)
        {
            return _entities.Where(x => x.Id == UserId).ToList();
        }
        public List<ApplicationUser> Get()
        {var User = _entities.Include(x => x.SellList).ToList();
            return User;
        }
    }
}

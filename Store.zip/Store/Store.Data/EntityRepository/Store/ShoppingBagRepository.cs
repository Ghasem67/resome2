﻿using Microsoft.EntityFrameworkCore;
using Store.Data.Contract.Store;
using Store.Data.Data;
using Store.Data.EntityRepository.BaseRepository;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.EntityRepository.Store
{
    public class ShoppingBagRepository : Repository<ShoppingBag>, IShoppingBagRepository
    {
        public ShoppingBagRepository(DataContext dataContext ) : base(dataContext)
        {
        }
       

        List<ShoppingBag> IShoppingBagRepository.GetbyId(int Id, CancellationToken cancellationToken)
        {
            return dataContext.ShoppingBags.Where(x => x.Id == Id).ToList();
        }
        List<ShoppingBag> IShoppingBagRepository.Get()
        {
            return dataContext.ShoppingBags.ToList();
        }
    }
}

﻿using Store.Entity.Base;
using Store.Entity.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Entity.Store
{
    public class Sell:BaseEntity<int>
    {
      
        public DateTime SellDate { get; set; }
        public int FactoreNumber { get; set; }
        public int UserId { get; set; }
        public ApplicationUser User { get; set; }=new ApplicationUser();
        public List<ShoppingBag> ShoppingBagList { get; set; } = new List<ShoppingBag>();


    }
}

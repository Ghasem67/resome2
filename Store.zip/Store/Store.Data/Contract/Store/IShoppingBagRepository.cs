﻿using Store.Data.Contract.BaseContract;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.Contract.Store
{
    public interface IShoppingBagRepository:IRepository<ShoppingBag>
    {
        List<ShoppingBag> GetbyId(int Id, CancellationToken cancellationToken);
        List<ShoppingBag> Get();
    }
}

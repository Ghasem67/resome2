﻿using Microsoft.EntityFrameworkCore;
using Store.Data.Contract.BaseContract;
using Store.Data.Data;
using Store.Entity.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Data.EntityRepository.BaseRepository
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class,IEntity
    {
        protected  DataContext dataContext;
        protected DbSet<TEntity> _entities;

        public Repository(DataContext dataContext  )
        {
            this.dataContext = dataContext;
            _entities = dataContext.Set<TEntity>();
        }

        

        public async Task   AddAsync(TEntity entity, CancellationToken cancellationToken)
        {
            dataContext.Add(entity);
          await  dataContext.SaveChangesAsync(cancellationToken);
        }

        public async Task DeleteAsync(TEntity entity, CancellationToken cancellationToken)
        {
           
             dataContext.Remove(entity);
            await dataContext.SaveChangesAsync(cancellationToken);
        }

        public async Task EditAsync(TEntity entity, CancellationToken cancellationToken)
        {
            dataContext.Update(entity);
            await dataContext.SaveChangesAsync(cancellationToken);
        }

       
       
    }
}

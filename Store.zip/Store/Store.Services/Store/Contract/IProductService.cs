﻿using Store.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Service.Store.Contract
{
    public interface IProductService
    {
        Task AddProduct(ProductDTO Productdto);
        Task EditProduct(ProductDTO Productdto);

        Task DeleteProduct(ProductDTO Productdto);
        List<ProductDTO> GetProductPagination(int PageNumber, int PageLength);
        ProductDTO GetOneProduct(int Id);
    }
}

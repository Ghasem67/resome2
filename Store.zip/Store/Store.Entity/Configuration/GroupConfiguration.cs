﻿using Microsoft.EntityFrameworkCore;
using Store.Entity.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store.Entity.Configuration
{
    public class GroupConfiguration : IEntityTypeConfiguration<Group>
    {
        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Group> builder)
        {
          builder.HasOne(x=>x.ParentGroup).WithMany(x=>x.Child).HasForeignKey(s=>s.ParentId).OnDelete(DeleteBehavior.NoAction);
        }
    }
}

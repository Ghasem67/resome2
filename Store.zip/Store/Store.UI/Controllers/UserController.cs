﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Store.Data.Data;
using Store.Entity.User;
using Store.Service.User.Contract;
using Store.Services.DTO;

namespace Store.UI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService userService;

        public UserController(IUserService IUserrepository)
        {
            userService = IUserrepository;
        }
        [Route("UserListPagination")]
        [HttpGet]
        public ActionResult<UserDTO> GetUserPagination(int pagenumber, int pagelength)
        {
            var UserList = userService.GetUserPagination(pagenumber,pagelength);
            return Ok(UserList);

        }
        [Route("OneUser")]
        [HttpGet]
        public ActionResult<UserDTO> GetOneUser(int Id)
        {
            var OneUser = userService.GetOneUser(Id);
            return Ok(OneUser);
        }
        [HttpPost]
        [Route("AddUser")]
        public ActionResult AddUser(UserDTO userDTO)
        {
            userService.AddUser(userDTO);
            return Ok();
        }
        [HttpPut]
        [Route("EditUser")]
        public ActionResult EditUser(UserDTO userDTO)
        {

           
            userService.EditUser(userDTO);

            return Ok();
        }
        [Route("DeleteUser")]
        [HttpDelete]
        public ActionResult DeleteUser(int Id)
        { 
            UserDTO UserDTO = new ()
            {
                Id = Id
            };
            userService.DeleteUser(UserDTO);
            return Ok();
        }
    }
}
